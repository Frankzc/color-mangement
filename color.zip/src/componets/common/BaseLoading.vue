// ===== src/components/common/BaseLoading.vue =====
<template>
  <div class="loading" v-if="show">
    <div class="loading__content">
      <div class="loading__spinner"></div>
      <p class="loading__text" v-if="text">{{ text }}</p>
    </div>
  </div>
</template>

<script setup>
defineProps({
  show: {
    type: Boolean,
    default: true
  },
  text: {
    type: String,
    default: '加载中...'
  }
})
</script>

<style lang="scss" scoped>
.loading {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(5px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  
  &__content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
  }
  
  &__spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #e5e7eb;
    border-top: 4px solid #3498db;
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }
  
  &__text {
    color: #6b7280;
    font-size: 0.875rem;
    margin: 0;
  }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>

// ===== src/components/common/BaseToast.vue =====
<template>
  <Teleport to="body">
    <Transition name="toast">
      <div 
        v-if="uiStore.toast.show"
        :class="[
          'toast',
          `toast--${uiStore.toast.type}`
        ]"
      >
        <div class="toast__content">
          <div class="toast__icon">
            <component :is="iconComponent" class="w-5 h-5" />
          </div>
          <p class="toast__message">{{ uiStore.toast.message }}</p>
          <button @click="uiStore.hideToast" class="toast__close">
            <XMarkIcon class="w-4 h-4" />
          </button>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { computed } from 'vue'
import { useUiStore } from '@stores/uiStore'
import { 
  CheckCircleIcon, 
  ExclamationTriangleIcon, 
  XCircleIcon, 
  InformationCircleIcon,
  XMarkIcon 
} from '@heroicons/vue/24/outline'

const uiStore = useUiStore()

const iconComponent = computed(() => {
  const iconMap = {
    success: CheckCircleIcon,
    warning: ExclamationTriangleIcon,
    error: XCircleIcon,
    info: InformationCircleIcon
  }
  return iconMap[uiStore.toast.type] || InformationCircleIcon
})
</script>

<style lang="scss" scoped>
.toast {
  position: fixed;
  top: 1rem;
  right: 1rem;
  min-width: 320px;
  max-width: 480px;
  border-radius: 0.75rem;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  z-index: 1100;
  
  &__content {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem;
  }
  
  &__icon {
    flex-shrink: 0;
  }
  
  &__message {
    flex: 1;
    margin: 0;
    font-size: 0.875rem;
    line-height: 1.25rem;
  }
  
  &__close {
    flex-shrink: 0;
    background: none;
    border: none;
    cursor: pointer;
    opacity: 0.7;
    transition: opacity 0.2s;
    
    &:hover {
      opacity: 1;
    }
  }
  
  &--info {
    background: #dbeafe;
    color: #1e40af;
    border: 1px solid #93c5fd;
  }
  
  &--success {
    background: #dcfce7;
    color: #166534;
    border: 1px solid #86efac;
  }
  
  &--warning {
    background: #fef3c7;
    color: #92400e;
    border: 1px solid #fcd34d;
  }
  
  &--error {
    background: #fee2e2;
    color: #dc2626;
    border: 1px solid #fca5a5;
  }
}

.toast-enter-active,
.toast-leave-active {
  transition: all 0.3s ease;
}

.toast-enter-from {
  transform: translateX(100%);
  opacity: 0;
}

.toast-leave-to {
  transform: translateX(100%);
  opacity: 0;
}

@media (max-width: 640px) {
  .toast {
    right: 1rem;
    left: 1rem;
    min-width: auto;
  }
}
</style>

// ===== src/components/common/BaseButton.vue =====
<template>
  <button
    :class="[
      'btn',
      `btn--${variant}`,
      `btn--${size}`,
      {
        'btn--loading': loading,
        'btn--outline': outline,
        'btn--block': block
      }
    ]"
    :disabled="disabled || loading"
    @click="handleClick"
  >
    <div v-if="loading" class="btn__spinner"></div>
    <slot v-else />
  </button>
</template>

<script setup>
const emit = defineEmits(['click'])

defineProps({
  variant: {
    type: String,
    default: 'primary',
    validator: (value) => ['primary', 'secondary', 'success', 'warning', 'danger'].includes(value)
  },
  size: {
    type: String,
    default: 'md',
    validator: (value) => ['sm', 'md', 'lg'].includes(value)
  },
  outline: {
    type: Boolean,
    default: false
  },
  block: {
    type: Boolean,
    default: false
  },
  loading: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  }
})

const handleClick = (event) => {
  emit('click', event)
}
</script>

<style lang="scss" scoped>
.btn {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 2px solid transparent;
  border-radius: 0.5rem;
  font-weight: 500;
  transition: all 0.2s;
  cursor: pointer;
  text-decoration: none;
  
  &:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none !important;
  }
  
  // 尺寸
  &--sm {
    padding: 0.5rem 0.75rem;
    font-size: 0.875rem;
  }
  
  &--md {
    padding: 0.625rem 1rem;
    font-size: 0.875rem;
  }
  
  &--lg {
    padding: 0.75rem 1.5rem;
    font-size: 1rem;
  }
  
  // 变体
  &--primary {
    background: #3498db;
    color: white;
    
    &:hover:not(:disabled) {
      background: #2980b9;
      transform: translateY(-1px);
    }
  }
  
  &--secondary {
    background: #6c757d;
    color: white;
    
    &:hover:not(:disabled) {
      background: #5a6268;
      transform: translateY(-1px);
    }
  }
  
  &--success {
    background: #27ae60;
    color: white;
    
    &:hover:not(:disabled) {
      background: #229954;
      transform: translateY(-1px);
    }
  }
  
  &--warning {
    background: #f39c12;
    color: white;
    
    &:hover:not(:disabled) {
      background: #e67e22;
      transform: translateY(-1px);
    }
  }
  
  &--danger {
    background: #e74c3c;
    color: white;
    
    &:hover:not(:disabled) {
      background: #c0392b;
      transform: translateY(-1px);
    }
  }
  
  // 轮廓样式
  &--outline {
    background: transparent;
    border-color: currentColor;
    
    &.btn--primary {
      color: #3498db;
      &:hover:not(:disabled) {
        background: #3498db;
        color: white;
      }
    }
    
    &.btn--secondary {
      color: #6c757d;
      &:hover:not(:disabled) {
        background: #6c757d;
        color: white;
      }
    }
    
    &.btn--success {
      color: #27ae60;
      &:hover:not(:disabled) {
        background: #27ae60;
        color: white;
      }
    }
    
    &.btn--warning {
      color: #f39c12;
      &:hover:not(:disabled) {
        background: #f39c12;
        color: white;
      }
    }
    
    &.btn--danger {
      color: #e74c3c;
      &:hover:not(:disabled) {
        background: #e74c3c;
        color: white;
      }
    }
  }
  
  // 块级
  &--block {
    width: 100%;
  }
  
  // 加载状态
  &--loading {
    pointer-events: none;
  }
  
  &__spinner {
    width: 1rem;
    height: 1rem;
    border: 2px solid transparent;
    border-top: 2px solid currentColor;
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>

// ===== src/components/navigation/MainNav.vue =====
<template>
  <nav class="main-nav">
    <div class="main-nav__container">
      <!-- Logo -->
      <div class="main-nav__logo">
        <router-link to="/" class="main-nav__brand">
          <h1 class="main-nav__title">Fashion Color</h1>
          <p class="main-nav__subtitle">时装设计师颜色管理系统</p>
        </router-link>
      </div>
      
      <!-- 导航菜单 -->
      <div class="main-nav__menu" :class="{ 'main-nav__menu--open': mobileMenuOpen }">
        <router-link
          v-for="item in navItems"
          :key="item.name"
          :to="item.path"
          class="main-nav__item"
          @click="closeMobileMenu"
        >
          <component :is="item.icon" class="main-nav__icon" />
          <span>{{ item.label }}</span>
        </router-link>
      </div>
      
      <!-- 用户操作 -->
      <div class="main-nav__actions">
        <!-- 收藏计数 -->
        <div class="main-nav__favorites" v-if="favoriteStore.favoriteCount > 0">
          <router-link to="/favorites" class="main-nav__favorites-link">
            <HeartIcon class="w-5 h-5" />
            <span class="main-nav__favorites-count">{{ favoriteStore.favoriteCount }}</span>
          </router-link>
        </div>
        
        <!-- 用户菜单 -->
        <div class="main-nav__user" v-if="userStore.isAuthenticated">
          <button @click="toggleUserMenu" class="main-nav__user-button">
            <UserCircleIcon class="w-6 h-6" />
          </button>
          
          <!-- 用户下拉菜单 -->
          <div v-if="userMenuOpen" class="main-nav__user-menu">
            <router-link to="/profile" class="main-nav__user-item">
              个人中心
            </router-link>
            <button @click="handleLogout" class="main-nav__user-item">
              退出登录
            </button>
          </div>
        </div>
        
        <!-- 登录按钮 -->
        <router-link v-else to="/login" class="main-nav__login">
          登录
        </router-link>
        
        <!-- 移动端菜单按钮 -->
        <button
          @click="toggleMobileMenu"
          class="main-nav__mobile-toggle"
        >
          <Bars3Icon v-if="!mobileMenuOpen" class="w-6 h-6" />
          <XMarkIcon v-else class="w-6 h-6" />
        </button>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import { useFavoriteStore } from '@stores/favoriteStore'
import { useUserStore } from '@stores/userStore'
import {
  MagnifyingGlassIcon,
  PhotoIcon,
  ColorSwatchIcon,
  HeartIcon,
  UserCircleIcon,
  Bars3Icon,
  XMarkIcon
} from '@heroicons/vue/24/outline'

const route = useRoute()
const favoriteStore = useFavoriteStore()
const userStore = useUserStore()

const mobileMenuOpen = ref(false)
const userMenuOpen = ref(false)

const navItems = [
  {
    name: 'search',
    path: '/',
    label: '颜色搜索',
    icon: MagnifyingGlassIcon
  },
  {
    name: 'extract',
    path: '/extract',
    label: '图片取色',
    icon: PhotoIcon
  },
  {
    name: 'wheel',
    path: '/wheel',
    label: '色环选色',
    icon: ColorSwatchIcon
  },
  {
    name: 'favorites',
    path: '/favorites',
    label: '我的收藏',
    icon: HeartIcon
  }
]

const toggleMobileMenu = () => {
  mobileMenuOpen.value = !mobileMenuOpen.value
}

const closeMobileMenu = () => {
  mobileMenuOpen.value = false
}

const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value
}

const handleLogout = () => {
  userStore.logout()
  userMenuOpen.value = false
}

// 点击外部关闭菜单
const handleClickOutside = (event) => {
  if (!event.target.closest('.main-nav__user')) {
    userMenuOpen.value = false
  }
  if (!event.target.closest('.main-nav__menu') && !event.target.closest('.main-nav__mobile-toggle')) {
    mobileMenuOpen.value = false
  }
}

onMounted(() => {
  document.addEventListener('click', handleClickOutside)
})

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside)
})
</script>

<style lang="scss" scoped>
.main-nav {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid #e5e7eb;
  position: sticky;
  top: 0;
  z-index: 100;
  
  &__container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 1rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 4rem;
    
    @media (min-width: 1024px) {
      padding: 0 2rem;
    }
  }
  
  &__logo {
    flex-shrink: 0;
  }
  
  &__brand {
    display: block;
    text-decoration: none;
    color: inherit;
  }
  
  &__title {
    font-size: 1.25rem;
    font-weight: 700;
    color: #2c3e50;
    margin: 0;
    line-height: 1.2;
  }
  
  &__subtitle {
    font-size: 0.75rem;
    color: #6b7280;
    margin: 0;
    line-height: 1;
  }
  
  &__menu {
    display: none;
    gap: 2rem;
    
    @media (min-width: 768px) {
      display: flex;
    }
    
    // 移动端菜单
    @media (max-width: 767px) {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: white;
      border-bottom: 1px solid #e5e7eb;
      flex-direction: column;
      padding: 1rem;
      gap: 0;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
      
      &--open {
        display: flex;
      }
    }
  }
  
  &__item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    text-decoration: none;
    color: #6b7280;
    font-weight: 500;
    border-radius: 0.5rem;
    transition: all 0.2s;
    
    &:hover {
      color: #3498db;
      background: #f1f5f9;
    }
    
    &.router-link-active {
      color: #3498db;
      background: #dbeafe;
    }
    
    @media (max-width: 767px) {
      padding: 0.75rem 0;
      border-bottom: 1px solid #f3f4f6;
      border-radius: 0;
      
      &:last-child {
        border-bottom: none;
      }
    }
  }
  
  &__icon {
    width: 1.25rem;
    height: 1.25rem;
  }
  
  &__actions {
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  
  &__favorites {
    position: relative;
  }
  
  &__favorites-link {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.5rem;
    text-decoration: none;
    color: #e74c3c;
    border-radius: 0.5rem;
    transition: all 0.2s;
    
    &:hover {
      background: #fef2f2;
    }
  }
  
  &__favorites-count {
    background: #e74c3c;
    color: white;
    font-size: 0.75rem;
    font-weight: 600;
    padding: 0.125rem 0.375rem;
    border-radius: 9999px;
    min-width: 1.25rem;
    text-align: center;
  }
  
  &__user {
    position: relative;
  }
  
  &__user-button {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0.25rem;
    border-radius: 50%;
    color: #6b7280;
    transition: all 0.2s;
    
    &:hover {
      color: #3498db;
      background: #f1f5f9;
    }
  }
  
  &__user-menu {
    position: absolute;
    top: 100%;
    right: 0;
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    min-width: 8rem;
    z-index: 50;
  }
  
  &__user-item {
    display: block;
    width: 100%;
    padding: 0.75rem 1rem;
    text-decoration: none;
    color: #374151;
    background: none;
    border: none;
    text-align: left;
    cursor: pointer;
    transition: background-color 0.2s;
    
    &:hover {
      background: #f9fafb;
    }
    
    &:first-child {
      border-radius: 0.5rem 0.5rem 0 0;
    }
    
    &:last-child {
      border-radius: 0 0 0.5rem 0.5rem;
    }
  }
  
  &__login {
    @include button-style(#3498db);
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
    text-decoration: none;
  }
  
  &__mobile-toggle {
    display: block;
    background: none;
    border: none;
    cursor: pointer;
    padding: 0.25rem;
    color: #6b7280;
    
    @media (min-width: 768px) {
      display: none;
    }
  }
}
</style>

// ===== src/components/color/ColorCard.vue =====
<template>
  <div class="color-card" @click="handleCardClick">
    <div 
      class="color-card__preview"
      :style="{ backgroundColor: color.hex }"
    >
      <!-- 收藏按钮 -->
      <button
        @click.stop="handleFavoriteClick"
        class="color-card__favorite"
        :class="{ 'color-card__favorite--active': isFavorite }"
      >
        <HeartIcon 
          :class="[
            'w-5 h-5',
            isFavorite ? 'fill-current' : ''
          ]"
        />
      </button>
      
      <!-- 对比色文字 -->
      <div 
        class="color-card__hex"
        :style="{ color: color.contrast }"
      >
        {{ color.hex }}
      </div>
    </div>
    
    <div class="color-card__info">
      <div class="color-card__name">
        <h3>{{ color.chinese }}</h3>
        <p class="color-card__english">{{ color.english }}</p>
      </div>
      
      <div class="color-card__details">
        <p class="color-card__category">{{ color.category }}</p>
        <p class="color-card__rgb">
          RGB({{ color.rgb.r }}, {{ color.rgb.g }}, {{ color.rgb.b }})
        </p>
        <p v-if="color.guofeng" class="color-card__guofeng">
          国风：{{ color.guofeng }}
        </p>
      </div>
      
      <!-- 标签 -->
      <div class="color-card__tags" v-if="color.tags.length > 0">
        <span
          v-for="tag in color.tags.slice(0, 3)"
          :key="tag"
          class="color-card__tag"
          :class="getTagClass(tag)"
        >
          {{ tag }}
        </span>
        <span v-if="color.tags.length > 3" class="color-card__tag-more">
          +{{ color.tags.length - 3 }}
        </span>
      </div>
      
      <!-- 操作按钮 -->
      <div class="color-card__actions">
        <BaseButton
          size="sm"
          variant="secondary"
          @click.stop="handleCopyHex"
        >
          复制 HEX
        </BaseButton>
        
        <BaseButton
          size="sm"
          variant="primary"
          @click.stop="handleViewDetails"
        >
          查看详情
        </BaseButton>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useFavoriteStore } from '@stores/favoriteStore'
import { useUiStore } from '@stores/uiStore'
import { HeartIcon } from '@heroicons/vue/24/outline'
import BaseButton from '@components/common/BaseButton.vue'

const props = defineProps({
  color: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['click', 'view-details'])

const favoriteStore = useFavoriteStore()
const uiStore = useUiStore()

const isFavorite = computed(() => favoriteStore.isFavorite(props.color.hex))

const handleCardClick = () => {
  emit('click', props.color)
}

const handleFavoriteClick = () => {
  favoriteStore.toggleFavorite(props.color)
  const message = isFavorite.value ? '已添加到收藏' : '已从收藏中移除'
  uiStore.showToast(message, 'success', 2000)
}

const handleCopyHex = async () => {
  try {
    await navigator.clipboard.writeText(props.color.hex)
    uiStore.showToast('HEX 值已复制到剪贴板', 'success', 2000)
  } catch (error) {
    console.error('复制失败:', error)
    uiStore.showToast('复制失败，请手动复制', 'error')
  }
}

const handleViewDetails = () => {
  emit('view-details', props.color)
}

const getTagClass = (tag) => {
  if (tag.includes('时尚')) return 'color-card__tag--fashion'
  if (tag.includes('季')) return 'color-card__tag--season'
  if (tag.includes('风格')) return 'color-card__tag--style'
  return ''
}
</script>

<style lang="scss" scoped>
.color-card {
  @include card-style;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  }
  
  &__preview {
    height: 120px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  &__favorite {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(5px);
    border: none;
    border-radius: 50%;
    width: 2rem;
    height: 2rem;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    
    &:hover {
      transform: scale(1.1);
      background: rgba(255, 255, 255, 1);
    }
    
    &--active {
      color: #e74c3c;
    }
  }
  
  &__hex {
    font-family: 'Monaco', 'Menlo', monospace;
    font-weight: 600;
    font-size: 0.875rem;
    background: rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(5px);
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
  }
  
  &__info {
    padding: 1rem;
  }
  
  &__name {
    margin-bottom: 0.5rem;
    
    h3 {
      font-size: 1rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 0.25rem 0;
    }
  }
  
  &__english {
    font-size: 0.75rem;
    color: #6b7280;
    margin: 0;
    font-style: italic;
  }
  
  &__details {
    margin-bottom: 0.75rem;
    
    p {
      font-size: 0.75rem;
      color: #6b7280;
      margin: 0.125rem 0;
    }
  }
  
  &__category {
    font-weight: 500;
    color: #3498db !important;
  }
  
  &__guofeng {
    color: #e74c3c !important;
    font-weight: 500;
  }
  
  &__tags {
    display: flex;
    flex-wrap: wrap;
    gap: 0.25rem;
    margin-bottom: 0.75rem;
  }
  
  &__tag {
    @extend .tag;
    font-size: 0.625rem;
    padding: 0.125rem 0.375rem;
    
    &--fashion {
      background: #e91e63;
      color: white;
    }
    
    &--season {
      background: #27ae60;
      color: white;
    }
    
    &--style {
      background: #9b59b6;
      color: white;
    }
  }
  
  &__tag-more {
    font-size: 0.625rem;
    color: #6b7280;
    font-weight: 500;
  }
  
  &__actions {
    display: flex;
    gap: 0.5rem;
  }
}

// 移动端优化
@media (max-width: 640px) {
  .color-card {
    &__actions {
      flex-direction: column;
    }
  }
}
</style>